const PostFormData = (props) => {
    return (
        <div>
            
        </div>
    )
}

export default PostFormData
